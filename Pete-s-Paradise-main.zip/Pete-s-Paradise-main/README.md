# Pete-s-Paradise

Do you hate student debt?

Do you wish that you could pay your tuition with dining dollars?

Do you ever want to know what it feels like to have a PHD from Purdue?

If you answered yes to any of these questions, Pete's Paradise is the game for you!

Click on Pete to earn dining dollars, make him happy and gain prestige 😎

ENJOY!

## How to Run?

Clone repository

Run `index.html`


